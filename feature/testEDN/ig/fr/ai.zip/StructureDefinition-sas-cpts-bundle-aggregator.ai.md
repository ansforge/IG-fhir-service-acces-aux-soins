# BundleAgregateurCPTS - Service d'Accès aux Soins v1.2.0

## Profil de ressource: BundleAgregateurCPTS 

 
Profil de Bundle qui représente le flux de réponse contenant les créneaux disponibles dans le cadre du service d'agrégation de créneaux de la plateforme SAS - Cas d'usage CPTS 

**Utilisations:**

* Exemples pour ce/t/te Profil: [Bundle/ExampleBundleCPTS1](Bundle-ExampleBundleCPTS1.md) and [Bundle/ExampleBundleCPTS2](Bundle-ExampleBundleCPTS2.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.sas|current/StructureDefinition/sas-cpts-bundle-aggregator)

### Vues formelles du contenu du profil

 [Description des profils, des différentiels, des instantanés et de leurs représentations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tableau des éléments clés](#tabs-key) 
*  [Tableau différentiel (differential)](#tabs-diff) 
*  [Tableau récapitulatif (snapshot)](#tabs-snap) 
*  [Statistiques/Références](#tabs-summ) 
*  [Tous](#tabs-all) 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [Bundle](http://hl7.org/fhir/R4/bundle.html) 

** Résumé **

Obligatoire : 10 éléments(2 éléments obligatoire(s) imbriqué(s))

**Structures**

Cette structure fait référence à ces autres structures:

* [FrSlotAgregateurCPTS (https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-slot-aggregator)](StructureDefinition-sas-cpts-slot-aggregator.md)
* [FrScheduleAgregateur (http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur)](StructureDefinition-FrScheduleAgregateur.md)
* [FrPractitionerAgregateur (http://sas.fr/fhir/StructureDefinition/FrPractitionerAgregateur)](StructureDefinition-FrPractitionerAgregateur.md)
* [FrPractitionerRoleExerciceAgregateur (http://sas.fr/fhir/StructureDefinition/FrPractitionerRoleExerciceAgregateur)](StructureDefinition-FrPractitionerRoleExerciceAgregateur.md)
* [FrHealthcareServiceAgregateurCPTS (https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-healthcareservice-aggregator)](StructureDefinition-sas-cpts-healthcareservice-aggregator.md)
* [FrOrganizationAgregateurCPTS (https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-organization-aggregator)](StructureDefinition-sas-cpts-organization-aggregator.md)

**Slices**

Cette structure définit les [slices](http://hl7.org/fhir/R4/profiling.html#slices) suivantes:

* The element 1 is sliced based on the value of Bundle.entry

 **Vue des éléments clés** 

#### Bindings terminologiques

#### Contraintes

 **Vue différentielle** 

Cette structure est dérivée de [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Vue d'ensembleView** 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [Bundle](http://hl7.org/fhir/R4/bundle.html) 

** Résumé **

Obligatoire : 10 éléments(2 éléments obligatoire(s) imbriqué(s))

**Structures**

Cette structure fait référence à ces autres structures:

* [FrSlotAgregateurCPTS (https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-slot-aggregator)](StructureDefinition-sas-cpts-slot-aggregator.md)
* [FrScheduleAgregateur (http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur)](StructureDefinition-FrScheduleAgregateur.md)
* [FrPractitionerAgregateur (http://sas.fr/fhir/StructureDefinition/FrPractitionerAgregateur)](StructureDefinition-FrPractitionerAgregateur.md)
* [FrPractitionerRoleExerciceAgregateur (http://sas.fr/fhir/StructureDefinition/FrPractitionerRoleExerciceAgregateur)](StructureDefinition-FrPractitionerRoleExerciceAgregateur.md)
* [FrHealthcareServiceAgregateurCPTS (https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-healthcareservice-aggregator)](StructureDefinition-sas-cpts-healthcareservice-aggregator.md)
* [FrOrganizationAgregateurCPTS (https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-organization-aggregator)](StructureDefinition-sas-cpts-organization-aggregator.md)

**Slices**

Cette structure définit les [slices](http://hl7.org/fhir/R4/profiling.html#slices) suivantes:

* The element 1 is sliced based on the value of Bundle.entry

 

Autres représentations du profil : [CSV](../StructureDefinition-sas-cpts-bundle-aggregator.csv), [Excel](../StructureDefinition-sas-cpts-bundle-aggregator.xlsx), [Schematron](../StructureDefinition-sas-cpts-bundle-aggregator.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "sas-cpts-bundle-aggregator",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-bundle-aggregator",
  "version" : "1.2.0",
  "name" : "BundleAgregateurCPTS",
  "status" : "active",
  "date" : "2026-07-22T14:55:39+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Profil de Bundle qui représente le flux de réponse contenant les créneaux disponibles dans le cadre du service d'agrégation de créneaux de la plateforme SAS - Cas d'usage CPTS",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Bundle",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.type",
      "path" : "Bundle.type",
      "patternCode" : "searchset"
    },
    {
      "id" : "Bundle.total",
      "path" : "Bundle.total",
      "min" : 1
    },
    {
      "id" : "Bundle.link",
      "path" : "Bundle.link",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resource"
        }],
        "rules" : "open"
      },
      "min" : 4
    },
    {
      "id" : "Bundle.entry:slotAgregateurCPTS",
      "path" : "Bundle.entry",
      "sliceName" : "slotAgregateurCPTS",
      "min" : 1,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:slotAgregateurCPTS.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:slotAgregateurCPTS.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Slot",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-slot-aggregator"]
      }]
    },
    {
      "id" : "Bundle.entry:scheduleAgregateurCPTS",
      "path" : "Bundle.entry",
      "sliceName" : "scheduleAgregateurCPTS",
      "min" : 1,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:scheduleAgregateurCPTS.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:scheduleAgregateurCPTS.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Schedule",
        "profile" : ["http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur"]
      }]
    },
    {
      "id" : "Bundle.entry:practitionerAgregateur",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerAgregateur",
      "min" : 1,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:practitionerAgregateur.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:practitionerAgregateur.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Practitioner",
        "profile" : ["http://sas.fr/fhir/StructureDefinition/FrPractitionerAgregateur"]
      }]
    },
    {
      "id" : "Bundle.entry:practitionerRole",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerRole",
      "min" : 1,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:practitionerRole.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:practitionerRole.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "PractitionerRole",
        "profile" : ["http://sas.fr/fhir/StructureDefinition/FrPractitionerRoleExerciceAgregateur"]
      }]
    },
    {
      "id" : "Bundle.entry:healthcareserviceCPTS",
      "path" : "Bundle.entry",
      "sliceName" : "healthcareserviceCPTS",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:healthcareserviceCPTS.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:healthcareserviceCPTS.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "HealthcareService",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-healthcareservice-aggregator"]
      }]
    },
    {
      "id" : "Bundle.entry:organizationAgregateurCPTS",
      "path" : "Bundle.entry",
      "sliceName" : "organizationAgregateurCPTS",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:organizationAgregateurCPTS.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "min" : 1
    },
    {
      "id" : "Bundle.entry:organizationAgregateurCPTS.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Organization",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-organization-aggregator"]
      }]
    }]
  }
}

```
