# FrSlotAgregateur - Service d'Accès aux Soins v1.2.0

## Profil de ressource: FrSlotAgregateur 

 
Profil de Slot, dérivé de FrSlot, pour le service d'agrégation de créneaux de la plateforme SAS - Commun cas d'usage PS Indiv et CPTS 

**Utilisations:**

* Utilise ce/t/te Profil: [BundleAgregateur](StructureDefinition-BundleAgregateur.md)
* Exemples pour ce/t/te Profil: [Slot/ExampleSlotPSIndiv1](Slot-ExampleSlotPSIndiv1.md), [Slot/ExampleSlotPSIndiv2](Slot-ExampleSlotPSIndiv2.md), [Slot/ExampleSlotPSIndiv3](Slot-ExampleSlotPSIndiv3.md), [Slot/ExampleSlotPSIndiv4](Slot-ExampleSlotPSIndiv4.md) and [Slot/ExampleSlotPSIndiv5](Slot-ExampleSlotPSIndiv5.md)
* CapabilityStatements utilisant ce Profil: [Profil SAS consommateur de créneaux](CapabilityStatement-SAS-Consommateur-psindiv.md) and [Profil SAS gestionnaire d'agenda PS Indiv](CapabilityStatement-SAS-GestionnaireAgenda-PsIndiv.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.sas|current/StructureDefinition/FrSlotAgregateur)

### Vues formelles du contenu du profil

 [Description des profils, des différentiels, des instantanés et de leurs représentations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tableau des éléments clés](#tabs-key) 
*  [Tableau différentiel (differential)](#tabs-diff) 
*  [Tableau récapitulatif (snapshot)](#tabs-snap) 
*  [Statistiques/Références](#tabs-summ) 
*  [Tous](#tabs-all) 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [FrSlot](https://simplifier.net/resolve?scope=hl7.fhir.fr.core@1.1.0&canonical=http://interopsante.org/fhir/StructureDefinition/FrSlot) 

#### Bindings terminologiques (différentiel)

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [FrSlot](https://simplifier.net/resolve?scope=hl7.fhir.fr.core@1.1.0&canonical=http://interopsante.org/fhir/StructureDefinition/FrSlot) 

** Résumé **

Obligatoire : 0 élément(1 élément obligatoire(s) imbriqué(s))
 Fixe : 1 élément

**Structures**

Cette structure fait référence à ces autres structures:

* [FrScheduleAgregateur (http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur)](StructureDefinition-FrScheduleAgregateur.md)

**Slices**

Cette structure définit les [slices](http://hl7.org/fhir/R4/profiling.html#slices) suivantes:

* The element 1 is sliced based on the value of Slot.serviceType

 **Vue des éléments clés** 

#### Bindings terminologiques

#### Contraintes

 **Vue différentielle** 

Cette structure est dérivée de [FrSlot](https://simplifier.net/resolve?scope=hl7.fhir.fr.core@1.1.0&canonical=http://interopsante.org/fhir/StructureDefinition/FrSlot) 

#### Bindings terminologiques (différentiel)

 **Vue d'ensembleView** 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [FrSlot](https://simplifier.net/resolve?scope=hl7.fhir.fr.core@1.1.0&canonical=http://interopsante.org/fhir/StructureDefinition/FrSlot) 

** Résumé **

Obligatoire : 0 élément(1 élément obligatoire(s) imbriqué(s))
 Fixe : 1 élément

**Structures**

Cette structure fait référence à ces autres structures:

* [FrScheduleAgregateur (http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur)](StructureDefinition-FrScheduleAgregateur.md)

**Slices**

Cette structure définit les [slices](http://hl7.org/fhir/R4/profiling.html#slices) suivantes:

* The element 1 is sliced based on the value of Slot.serviceType

 

Autres représentations du profil : [CSV](../StructureDefinition-FrSlotAgregateur.csv), [Excel](../StructureDefinition-FrSlotAgregateur.xlsx), [Schematron](../StructureDefinition-FrSlotAgregateur.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FrSlotAgregateur",
  "url" : "http://sas.fr/fhir/StructureDefinition/FrSlotAgregateur",
  "version" : "1.2.0",
  "name" : "FrSlotAgregateur",
  "status" : "active",
  "date" : "2026-07-17T08:54:08+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Profil de Slot, dérivé de FrSlot, pour le service d'agrégation de créneaux de la plateforme SAS - Commun cas d'usage PS Indiv et CPTS",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "resource",
  "abstract" : false,
  "type" : "Slot",
  "baseDefinition" : "http://interopsante.org/fhir/StructureDefinition/FrSlot",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Slot.meta.security",
      "path" : "Slot.meta.security",
      "binding" : {
        "strength" : "required",
        "description" : "type de créneau : public, pro, SNP",
        "valueSet" : "https://mos.esante.gouv.fr/NOS/JDV_J165-TypeCreneau-SAS/FHIR/JDV-J165-TypeCreneau-SAS"
      }
    },
    {
      "id" : "Slot.serviceType",
      "path" : "Slot.serviceType",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "coding.system"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "Slot.serviceType:TypeConsultation",
      "path" : "Slot.serviceType",
      "sliceName" : "TypeConsultation",
      "min" : 0,
      "max" : "*",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v3-ActEncounterCode"
      }
    },
    {
      "id" : "Slot.serviceType:TypeConsultation.coding.system",
      "path" : "Slot.serviceType.coding.system",
      "min" : 1,
      "patternUri" : "http://terminology.hl7.org/CodeSystem/v3-ActCode"
    },
    {
      "id" : "Slot.specialty",
      "path" : "Slot.specialty",
      "binding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName",
          "valueString" : "specialty"
        }],
        "strength" : "required",
        "description" : "Spécialités ou compétences particulières du PS associées au créneau",
        "valueSet" : "http://interopsante.org/fhir/ValueSet/fr-practitioner-specialty"
      }
    },
    {
      "id" : "Slot.appointmentType",
      "path" : "Slot.appointmentType",
      "short" : "Créneau avec ou sans RDV",
      "binding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName",
          "valueString" : "appointment-type"
        }],
        "strength" : "preferred",
        "description" : "ROUTINE – Créneau avec prise de RDV possible, WALKIN – Créneau sans prise de RDV possible",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0276"
      }
    },
    {
      "id" : "Slot.schedule",
      "path" : "Slot.schedule",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur"],
        "aggregation" : ["referenced", "bundled"]
      }]
    },
    {
      "id" : "Slot.status",
      "path" : "Slot.status",
      "fixedCode" : "free",
      "binding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName",
          "valueString" : "SlotStatus"
        }],
        "strength" : "required",
        "description" : "Statut du créneau free/busy",
        "valueSet" : "http://hl7.org/fhir/ValueSet/slotstatus"
      }
    },
    {
      "id" : "Slot.start",
      "path" : "Slot.start",
      "short" : "Date de début du créneau",
      "definition" : "Date de début du créneau"
    },
    {
      "id" : "Slot.end",
      "path" : "Slot.end",
      "short" : "Date de fin du créneau",
      "definition" : "Date de fin du créneau"
    },
    {
      "id" : "Slot.comment",
      "path" : "Slot.comment",
      "short" : "URL permettant d’accéder à la prise de RDV relative à ce créneau",
      "definition" : "URL permettant d’accéder à la prise de RDV relative à ce créneau"
    }]
  }
}

```
