# ExampleBundleCPTS1 - Service d'Accès aux Soins v1.2.0

## Exemple Bundle: ExampleBundleCPTS1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleBundleCPTS1",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-bundle-aggregator"]
  },
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "http://hapi.fhir.org/baseR4/Slot?_include=Slot:schedule&_include:iterate=Schedule:actor&start=ge2024-06-12T16:20:00.000+02:00&start=le2024-06-12T17:20:00.000+02:00&schedule.actor:Practitioner.identifier=urn:oid:1.2.250.1.71.4.2.1|810002909371&status=free&_include=Slot:service-type-reference"
  }],
  "entry" : [{
    "fullUrl" : "https://<base_URl>/Slot/ExampleSlotCPTS1",
    "resource" : {
      "resourceType" : "Slot",
      "id" : "ExampleSlotCPTS1",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-slot-aggregator"],
        "security" : [{
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R314-TypeCreneau/FHIR/TRE-R314-TypeCreneau",
          "code" : "PUBLIC"
        },
        {
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R314-TypeCreneau/FHIR/TRE-R314-TypeCreneau",
          "code" : "CPTS"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"Slot_ExampleSlotCPTS1\"> </a><p class=\"res-header-id\"><b>Narratif généré : Slot ExampleSlotCPTS1</b></p><a name=\"ExampleSlotCPTS1\"> </a><a name=\"hcExampleSlotCPTS1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-sas-cpts-slot-aggregator.html\">FrSlotAgregateurCPTS</a></p><p style=\"margin-bottom: 0px\">Label de sécurités: <a href=\"https://smt.esante.gouv.fr/fhir/ValueSet/TRE-R314-TypeCreneau\">Créneau accessible par le grand public (Détails : code TRE_R314_TypeCreneau PUBLIC = 'Créneau accessible par le grand public')</a>, <a href=\"https://smt.esante.gouv.fr/fhir/ValueSet/TRE-R314-TypeCreneau\">Créneau accessible par les communautés professionnelles territoriales de santé (Détails : code TRE_R314_TypeCreneau CPTS = 'Créneau accessible par les communautés professionnelles territoriales de santé')</a></p></div><p><b>serviceType</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/v3-ActCode AMB}\">ambulatory</span>, <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R66-CategorieEtablissement/FHIR/TRE-R66-CategorieEtablissement 604}\">604</span>, <span title=\"Codes :\">Visite de contrôle</span></p><p><b>specialty</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R38-SpecialiteOrdinale/FHIR/TRE-R38-SpecialiteOrdinale SM54}\">Médecine générale (SM)</span></p><p><b>appointmentType</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/v2-0276 ROUTINE}\">Routine appointment - default if not valued</span></p><p><b>schedule</b>: <a href=\"Schedule-ExampleSchedule.html\">Schedule</a></p><p><b>status</b>: Free</p><p><b>start</b>: 2024-06-12 16:40:00+0200</p><p><b>end</b>: 2024-06-12 17:00:00+0200</p><p><b>comment</b>: https://exemple.com/rdv/com/</p></div></div>"
      },
      "serviceType" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "AMB"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Slot.serviceType",
          "valueReference" : {
            "reference" : "HealthcareService/ExampleHealthcareServiceCPTS1"
          }
        }],
        "coding" : [{
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R66-CategorieEtablissement/FHIR/TRE-R66-CategorieEtablissement",
          "code" : "604"
        }]
      },
      {
        "text" : "Visite de contrôle"
      }],
      "specialty" : [{
        "coding" : [{
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R38-SpecialiteOrdinale/FHIR/TRE-R38-SpecialiteOrdinale",
          "code" : "SM54"
        }]
      }],
      "appointmentType" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0276",
          "code" : "ROUTINE"
        }]
      },
      "schedule" : {
        "reference" : "Schedule/ExampleSchedule"
      },
      "status" : "free",
      "start" : "2024-06-12T16:40:00.000+02:00",
      "end" : "2024-06-12T17:00:00.000+02:00",
      "comment" : "https://exemple.com/rdv/com/"
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://<base_URl>/Schedule/ExampleSchedule",
    "resource" : {
      "resourceType" : "Schedule",
      "id" : "ExampleSchedule",
      "meta" : {
        "profile" : ["http://sas.fr/fhir/StructureDefinition/FrScheduleAgregateur"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"Schedule_ExampleSchedule\"> </a><p class=\"res-header-id\"><b>Narratif généré : Schedule ExampleSchedule</b></p><a name=\"ExampleSchedule\"> </a><a name=\"hcExampleSchedule\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-FrScheduleAgregateur.html\">FrScheduleAgregateur</a></p></div><p><b>actor</b>: </p><ul><li><a href=\"Practitioner-ExamplePractitioner.html\">Practitioner Pierre Foret </a></li><li><a href=\"PractitionerRole-ExamplePractitionerRoleAgregateur.html\">PractitionerRole : telecom = ph: +33561855977</a></li></ul></div></div>"
      },
      "actor" : [{
        "reference" : "Practitioner/ExamplePractitioner"
      },
      {
        "reference" : "PractitionerRole/ExamplePractitionerRoleAgregateur"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://<base_URl>/Practitioner/ExamplePractitioner",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "ExamplePractitioner",
      "meta" : {
        "profile" : ["http://sas.fr/fhir/StructureDefinition/FrPractitionerAgregateur"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"Practitioner_ExamplePractitioner\"> </a><p class=\"res-header-id\"><b>Narratif généré : Praticien ExamplePractitioner</b></p><a name=\"ExamplePractitioner\"> </a><a name=\"hcExamplePractitioner\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-FrPractitionerAgregateur.html\">FrPractitionerAgregateur</a></p></div><p><b>identifier</b>: Identifiant National de Professionnel de Santé/810002909371</p><p><b>name</b>: Pierre Foret </p></div></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://interopsante.org/fhir/CodeSystem/fr-v2-0203",
            "code" : "IDNPS"
          }]
        },
        "system" : "urn:oid:1.2.250.1.71.4.2.1",
        "value" : "810002909371"
      }],
      "name" : [{
        "family" : "Foret",
        "given" : ["Pierre"]
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://<base_URl>/PractitionerRole/ExamplePractitionerRoleAgregateur",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "ExamplePractitionerRoleAgregateur",
      "meta" : {
        "profile" : ["http://sas.fr/fhir/StructureDefinition/FrPractitionerRoleExerciceAgregateur"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"PractitionerRole_ExamplePractitionerRoleAgregateur\"> </a><p class=\"res-header-id\"><b>Narratif généré : PractitionerRole ExamplePractitionerRoleAgregateur</b></p><a name=\"ExamplePractitionerRoleAgregateur\"> </a><a name=\"hcExamplePractitionerRoleAgregateur\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-FrPractitionerRoleExerciceAgregateur.html\">FrPractitionerRoleExerciceAgregateur</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-ExamplePractitioner.html\">Practitioner Pierre Foret </a></p><p><b>organization</b>: Identifier: Identification nationale de structure définie par l’ASIP-SANTE dans le CI_SIS/412345678912345</p><p><b>location</b>: <a href=\"#hcExamplePractitionerRoleAgregateur/ExampleLocation\">Location : identifier = Identifiant interne</a></p><p><b>telecom</b>: <a href=\"tel:+33561855977\">+33561855977</a></p><hr/><blockquote><p class=\"res-header-id\"><b>Narratif généré : Localisation #ExampleLocation</b></p><a name=\"ExamplePractitionerRoleAgregateur/ExampleLocation\"> </a><a name=\"hcExamplePractitionerRoleAgregateur/ExampleLocation\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-FrLocationAgregateur.html\">FrLocationAgregateur</a></p></div><p><b>identifier</b>: Identifiant interne/123456789</p><p><b>address</b>: 25 CHEMIN DE MOUNESTIE Aussonne 31840 </p></blockquote></div></div>"
      },
      "contained" : [{
        "resourceType" : "Location",
        "id" : "ExampleLocation",
        "meta" : {
          "profile" : ["http://sas.fr/fhir/StructureDefinition/FrLocationAgregateur"]
        },
        "identifier" : [{
          "type" : {
            "coding" : [{
              "system" : "http://interopsante.org/fhir/CodeSystem/fr-location-identifier-type",
              "code" : "INTRN"
            }]
          },
          "system" : "https://editeur.com",
          "value" : "123456789"
        }],
        "address" : {
          "line" : ["25 CHEMIN DE MOUNESTIE"],
          "city" : "Aussonne",
          "postalCode" : "31840"
        }
      }],
      "practitioner" : {
        "reference" : "Practitioner/ExamplePractitioner"
      },
      "organization" : {
        "identifier" : {
          "type" : {
            "coding" : [{
              "system" : "http://interopsante.org/fhir/CodeSystem/fr-v2-0203",
              "code" : "IDNST"
            }]
          },
          "system" : "urn:oid:1.2.250.1.71.4.2.2",
          "value" : "412345678912345"
        }
      },
      "location" : [{
        "reference" : "#ExampleLocation"
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+33561855977"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://<base_URl>/HealthcareService/ExampleHealthcareServiceCPTS1",
    "resource" : {
      "resourceType" : "HealthcareService",
      "id" : "ExampleHealthcareServiceCPTS1",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-healthcareservice-aggregator"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"HealthcareService_ExampleHealthcareServiceCPTS1\"> </a><p class=\"res-header-id\"><b>Narratif généré : ServiceDeSanté ExampleHealthcareServiceCPTS1</b></p><a name=\"ExampleHealthcareServiceCPTS1\"> </a><a name=\"hcExampleHealthcareServiceCPTS1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-sas-cpts-healthcareservice-aggregator.html\">FrHealthcareServiceAgregateurCPTS</a></p></div><p><b>providedBy</b>: <a href=\"Organization-ExampleOrgaCPTS1.html\">Organization CPTS AXE MAJEUR</a></p></div></div>"
      },
      "providedBy" : {
        "reference" : "Organization/ExampleOrgaCPTS1"
      }
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://<base_URl>/Organization/ExampleOrgaCPTS1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "ExampleOrgaCPTS1",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-organization-aggregator"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"Organization_ExampleOrgaCPTS1\"> </a><p class=\"res-header-id\"><b>Narratif généré : Organisation ExampleOrgaCPTS1</b></p><a name=\"ExampleOrgaCPTS1\"> </a><a name=\"hcExampleOrgaCPTS1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-sas-cpts-organization-aggregator.html\">FrOrganizationAgregateurCPTS</a></p></div><p><b>identifier</b>: IDNST/1950047225</p><p><b>name</b>: CPTS AXE MAJEUR</p><p><b>telecom</b>: <a href=\"tel:+33102030405\">+33102030405</a></p></div></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
            "code" : "IDNST"
          }]
        },
        "system" : "urn:oid:1.2.250.1.71.4.2.2",
        "value" : "1950047225"
      }],
      "name" : "CPTS AXE MAJEUR",
      "telecom" : [{
        "system" : "phone",
        "value" : "+33102030405"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  }]
}

```
