# ExampleAppointmentSOS2 - Service d'Accès aux Soins v1.2.0

## Exemple Appointment: ExampleAppointmentSOS2

-------

**French**

-------

Profil: [FrAppointmentSASSOS](StructureDefinition-sas-sos-appointment.md)

**FrAppointmentOperator**: Identifier: Identifiant National de Professionnel de Santé/3456780581/11242343

**identifier**: `urn:oid:1.1.111.1.11.1.1.1`/b6e39355-8a61-4556-b340-36f7b95fec6a

**status**: Booked

**start**: 2022-09-04 14:00:00+0100

**end**: 2022-09-04 14:15:00+0100

### Participants

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Type** | **Actor** | **Status** |
| * | admitter | Identifier: Identifiant National de Professionnel de Santé/899700519632 | Accepted |



## Resource Content

```json
{
  "resourceType" : "Appointment",
  "id" : "123456789",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-sos-appointment"]
  },
  "extension" : [{
    "url" : "http://interopsante.org/fhir/StructureDefinition/FrAppointmentOperator",
    "valueReference" : {
      "identifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://interopsante.org/fhir/CodeSystem/fr-v2-0203",
            "code" : "IDNPS"
          }]
        },
        "system" : "urn:oid:1.2.250.1.71.4.2.1",
        "value" : "3456780581/11242343"
      }
    }
  }],
  "identifier" : [{
    "system" : "urn:oid:1.1.111.1.11.1.1.1",
    "value" : "b6e39355-8a61-4556-b340-36f7b95fec6a"
  }],
  "status" : "booked",
  "start" : "2022-09-04T14:00:00+01:00",
  "end" : "2022-09-04T14:15:00+01:00",
  "participant" : [{
    "type" : [{
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
        "code" : "ADM"
      }]
    }],
    "actor" : {
      "identifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://interopsante.org/fhir/CodeSystem/fr-v2-0203",
            "code" : "IDNPS"
          }]
        },
        "system" : "urn:oid:1.2.250.1.71.4.2.1",
        "value" : "899700519632"
      }
    },
    "status" : "accepted"
  }]
}

```
