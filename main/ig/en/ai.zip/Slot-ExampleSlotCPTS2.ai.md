# ExampleSlotCPTS2 - Service d'Accès aux Soins v1.2.0

## Example Slot: ExampleSlotCPTS2

-------

**English**

-------

Profile: [FrSlotAgregateurCPTS](StructureDefinition-sas-cpts-slot-aggregator.md)

Security Labels: [Créneau accessible par le grand public (Details: TRE_R314_TypeCreneau code PUBLIC = 'Créneau accessible par le grand public')](https://smt.esante.gouv.fr/fhir/ValueSet/TRE-R314-TypeCreneau), [Créneau accessible par les communautés professionnelles territoriales de santé (Details: TRE_R314_TypeCreneau code CPTS = 'Créneau accessible par les communautés professionnelles territoriales de santé')](https://smt.esante.gouv.fr/fhir/ValueSet/TRE-R314-TypeCreneau)

**serviceType**: Visite de contrôle, 604, 604

**specialty**: Médecine générale (SM)

**appointmentType**: Routine appointment - default if not valued

**schedule**: [Schedule](Schedule-ExampleSchedule.md)

**status**: Free

**start**: 2024-06-12 16:40:00+0200

**end**: 2024-06-12 17:00:00+0200

**comment**: https://exemple.com/rdv/com/



## Resource Content

```json
{
  "resourceType" : "Slot",
  "id" : "ExampleSlotCPTS2",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sas/StructureDefinition/sas-cpts-slot-aggregator"],
    "security" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R314-TypeCreneau/FHIR/TRE-R314-TypeCreneau",
      "code" : "PUBLIC"
    },
    {
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R314-TypeCreneau/FHIR/TRE-R314-TypeCreneau",
      "code" : "CPTS"
    }]
  },
  "serviceType" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "AMB"
    }],
    "text" : "Visite de contrôle"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Slot.serviceType",
      "valueReference" : {
        "reference" : "HealthcareService/ExampleHealthcareServiceCPTS1"
      }
    }],
    "coding" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R66-CategorieEtablissement/FHIR/TRE-R66-CategorieEtablissement",
      "code" : "604"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Slot.serviceType",
      "valueReference" : {
        "reference" : "HealthcareService/ExampleHealthcareServiceCPTS2"
      }
    }],
    "coding" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R66-CategorieEtablissement/FHIR/TRE-R66-CategorieEtablissement",
      "code" : "604"
    }]
  }],
  "specialty" : [{
    "coding" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R38-SpecialiteOrdinale/FHIR/TRE-R38-SpecialiteOrdinale",
      "code" : "SM54"
    }]
  }],
  "appointmentType" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0276",
      "code" : "ROUTINE"
    }]
  },
  "schedule" : {
    "reference" : "Schedule/ExampleSchedule"
  },
  "status" : "free",
  "start" : "2024-06-12T16:40:00.000+02:00",
  "end" : "2024-06-12T17:00:00.000+02:00",
  "comment" : "https://exemple.com/rdv/com/"
}

```
